import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class BookRental
{
	static
	{
		try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
		}
		catch (ClassNotFoundException cnfe)
		{
			cnfe.printStackTrace();
		}
	}
	
	static Scanner sc = new Scanner(System.in);
	
	//-------------------------메뉴관리-------------------------
	public static void mainMenu() 
	{
		System.out.println("[메뉴 선택]");
		System.out.println("1. 도서 관리(도서 등록/조회/삭제)");
		System.out.println("2. 회원 관리(회원 가입/조회/탈퇴)");
		System.out.println("3. 대출 관리(도서 대여/반납/연장)");
		System.out.println("4. 종료");
		System.out.print("선택 : ");
	}
	public static void registMenu() 
	{
		System.out.println("1. 도서 등록");
		System.out.println("2. 도서 조회");
		System.out.println("3. 전체 조회");
		System.out.println("4. 도서 삭제");
		System.out.println("5. 이전 메뉴");
		System.out.println("6. 종     료");
	}
	public static void memberMenu() 
	{
		System.out.println("1. 신규 가입");
		System.out.println("2. 정보 조회");
		System.out.println("3. 회원 탈퇴");
		System.out.println("4. 블랙리스트 등록");
		System.out.println("5. 블랙리스트 조회");
		System.out.println("6. 블랙리스트 해제");
		System.out.println("7. 이전 메뉴");
		System.out.println("8. 종     료");
	}
	public static void rentalMenu()
	{
		System.out.println("1. 도서 대여");
		System.out.println("2. 도서 반납");
		System.out.println("3. 대여 조회");
		System.out.println("4. 기간 연장");
		System.out.println("5. 이전 메뉴");
		System.out.println("6. 종     료");
	}
	//-------------------------도서관리-------------------------
	public static void addNumber(PreparedStatement pstmt, Connection con) 
	{
		System.out.print("도서 제목 : ");
		String booktitle = sc.nextLine();
		System.out.print("도서 번호 : ");
		String booknumber = sc.nextLine();
		System.out.print("도서 수량 : ");
		int bookcount = Integer.parseInt(sc.nextLine());
		
		try
		{
			// 기존에 있는 도서인지 확인
			String checkBookNum = "SELECT COUNT(*) FROM regist_book WHERE booknumber = ?";
			PreparedStatement pstmtCheck = con.prepareStatement(checkBookNum);
			pstmtCheck.setString(1, booknumber);
			ResultSet rs = pstmtCheck.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			
			if (count > 0)
			{
				// 기존에 있는 도서 수량 추가
				String updateBookIn = "UPDATE regist_book SET bookcount = bookcount + ? WHERE booknumber = ?";
				PreparedStatement pstmtU = con.prepareStatement(updateBookIn);
				pstmtU.setInt(1, bookcount);
				pstmtU.setString(2, booknumber);
				int updateCount = pstmtU.executeUpdate();
				System.out.println("도서 수량이 수정 되었습니다. (" + updateCount + ")");
				System.out.println();
			}
			else
			{
				// 새로운 도서 등록
				pstmt.setString(1, booktitle);
				pstmt.setString(2, booknumber);
				pstmt.setInt(3, bookcount);
				int updateCount = pstmt.executeUpdate();
				System.out.println("도서가 등록되었습니다.(" + updateCount + ")");
				System.out.println();
			}
		}
		catch (Exception e)
		{
			System.out.println("도서가 등록되지 않았습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void selNumber(PreparedStatement pstmt) 
	{
		System.out.print("조회할 도서 번호 : ");
		String search = sc.nextLine();
		
		try 
		{
			pstmt.setString(1, search);
			ResultSet rs = pstmt.executeQuery();
			int count = 0;
			while(rs.next())
			{
				count++;
				String booktitle = rs.getString("booktitle");
				String bookNumber = rs.getString("bookNumber");
				String bookcount = rs.getString("bookcount");
				System.out.println("도서 제목 : " + booktitle);
				System.out.println("도서 번호 : " + bookNumber);
				System.out.println("도서 수량 : " + bookcount);
				
			}
			if (count == 0)
				System.out.println("조회할 데이터가 없습니다.");
				System.out.println();
		}
		catch (Exception e)
		{
			System.out.println("조회 중 에러가 발생했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void selectAll(PreparedStatement pstmt) 
	{
		System.out.println("전체 리스트 조회");
		
		try 
		{
			ResultSet rs = pstmt.executeQuery();
			int count = 0;
			while(rs.next())
			{
				count++;
				String booktitle = rs.getString("booktitle");
				String booknumber = rs.getString("booknumber");
				String bookcount = rs.getString("bookcount");
				System.out.println("도서 번호:" + booknumber + ", " + "도서 수량:" + bookcount + ", " + "도서 제목:" + booktitle);
			}
			if (count == 0)
				System.out.println("조회할 데이터가 없습니다.");
				System.out.println();
		}
		catch (Exception e)
		{
			System.out.println("조회 중 에러가 발생했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void delNumber(PreparedStatement pstmt, PreparedStatement pstmtU, Connection con) 
	{
		System.out.print("삭제할 도서 번호 : ");
		String search = sc.nextLine();
		System.out.print("삭제할 수량 : ");
		int deleteCount = Integer.parseInt(sc.nextLine());
		
		try
		{
			// 기존에 있는 도서 수량 확인
			String checkBookIn = "SELECT bookcount FROM regist_book WHERE booknumber = ?";
			PreparedStatement pstmtCheckBookIn = con.prepareStatement(checkBookIn);
			pstmtCheckBookIn.setString(1, search);
			ResultSet rsCheckBookIn = pstmtCheckBookIn.executeQuery();
			if (rsCheckBookIn.next())
			{
				int bookInCount = Integer.parseInt(rsCheckBookIn.getString(1));
				if (bookInCount > deleteCount)
				{
					// 기존에 있는 도서 수량 감소
					pstmtU.setInt(1, deleteCount);
					pstmtU.setString(2, search);
					int updateCount = pstmtU.executeUpdate();
					System.out.println("도서 수량이 수정되었습니다. (" + updateCount + ")");
					System.out.println();
				} else if (bookInCount == deleteCount)
				{
					// 이미 대여된 도서의 수량 확인
					String checkRental = "SELECT COUNT(*) FROM rental_book WHERE booknumber = ?";
					PreparedStatement pstmtCheckRental = con.prepareStatement(checkRental);
					pstmtCheckRental.setString(1, search);
					ResultSet rsCheckRental = pstmtCheckRental.executeQuery();
					rsCheckRental.next();
					int countRental = rsCheckRental.getInt(1);
					if (countRental > 0)
					{
						// 기존에 있는 도서 수량을 1이하로 변경할 수 없음
						String updateBookIn = "UPDATE regist_book SET bookcount = '0' WHERE booknumber = ? AND booktitle = ?";
						pstmtU.setString(1, "0");
						pstmtU.setString(2, search);
						int updateCount = pstmtU.executeUpdate();
						System.out.println("대여 중인 도서가 있어 삭제할 수 없습니다. (" + updateCount + ")");
						System.out.println();
					} else
					{
						// 기존에 있는 도서 삭제
						pstmt.setString(1, search);
						int updateCount = pstmt.executeUpdate();
						System.out.println("도서 정보가 삭제되었습니다. (" + updateCount + ")");
						System.out.println();
					}
				} else
				{
					System.out.println("삭제하려는 도서수량이 현재 도서수량보다 많습니다.");
					System.out.println();
				}
			} else
			{
				System.out.println("해당하는 도서정보가 없습니다.");
				System.out.println();
			}
		} catch (Exception e)
		{
			System.out.println("도서정보가 삭제되지 않았습니다.\n" + e.getMessage());
			System.out.println();
		}
		
	}
	//-------------------------회원관리-------------------------
	public static void addMember(PreparedStatement pstmt, Connection con) 
	{
		System.out.print("ID : ");
		String id = sc.nextLine();
		System.out.print("이름 : ");
		String name = sc.nextLine();
		
		try
		{
			pstmt.setString(1, id);
			pstmt.setString(2, name);
			// 중복 아이디 확인
			String checkId = "SELECT COUNT(*) FROM member_book WHERE id = ?";
			PreparedStatement pstmtCheck = con.prepareStatement(checkId);
			pstmtCheck.setString(1, id);
			ResultSet rs = pstmtCheck.executeQuery();
			rs.next();
			
			int count = rs.getInt(1);
			
			if (count > 0)
			{
				System.out.println("이미 존재하는 아이디입니다.");
				System.out.println();
			} 
			else
			{
				int updateCount = pstmt.executeUpdate();
				System.out.println("회원가입이 완료되었습니다. (" + updateCount + ")");
				System.out.println();
			}
		}
		catch (Exception e)
		{
			e.getMessage();
		}
	}
	public static void selMember(PreparedStatement pstmt, PreparedStatement pstmtR, PreparedStatement pstmtB, PreparedStatement pstmtC) 
	{
		System.out.print("조회할 ID : ");
		String search = sc.nextLine();
		
		try 
		{
			pstmt.setString(1, search);
			ResultSet rs = pstmt.executeQuery();
			int count = 0;
			while(rs.next())
			{
				count++;
				String id = rs.getString("id");
				String name = rs.getString("name");
				System.out.println("사용자 ID : " + id);
				System.out.println("이름 : " + name);
				
				// 블랙리스트 상태 확인
				pstmtC.setString(1, id);
				ResultSet rsC = pstmtC.executeQuery();
				if (rsC.next())
					System.out.println("블랙리스트(Y/N) : Yes");
				else
					System.out.println("블랙리스트(Y/N) : No");
				
				// 대여한 책의 수 조회
				pstmtR.setString(1, id);
				ResultSet rs2 = pstmtR.executeQuery();
				rs2.next();
				int rentalCount = rs2.getInt(1);
				System.out.println("대여한 책의 수 : " + rentalCount);
				
				// 대여한 책의 도서 번호 확인
				pstmtB.setString(1, id);
				ResultSet rsB = pstmtB.executeQuery();
				System.out.print("대여한 도서 번호 : ");
				StringBuilder sb = new StringBuilder();
				while (rsB.next())
					sb.append(rsB.getString("booknumber") + ", ");
				if (sb.length() > 0)
					sb.setLength(sb.length() - 2);
				else
					sb.append("없음");
				System.out.println(sb.toString());
			}
			if (count == 0)
				System.out.println("조회할 데이터가 없습니다.");
				System.out.println();
		}
		catch (Exception e)
		{
			System.out.println("조회 중 에러가 발생했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void delMember(PreparedStatement pstmt, PreparedStatement pstmtR, Connection con)
	{
		System.out.print("삭제할 ID : ");
		String search = sc.nextLine();
		
		try 
		{
			// 반납하지 않은 도서 확인
			String checkRental = "SELECT COUNT(*) FROM rental_book WHERE id = ?";
			PreparedStatement pstmtCheckRental = con.prepareStatement(checkRental);
			pstmtCheckRental.setString(1, search);
			ResultSet rsCheckRental = pstmtCheckRental.executeQuery();
			rsCheckRental.next();
			
			int countRental = rsCheckRental.getInt(1);
			
			if (countRental > 0)
			{
				System.out.println("반납하지 않은 도서가 있어 삭제할 수 없습니다.");
				System.out.println();
			}
			else
			{
				// 블랙리스트 여부 확인
				String checkBlacklist = "SELECT COUNT(*) FROM black_book WHERE blackid = ?";
				PreparedStatement pstmtCheckBlacklist = con.prepareStatement(checkBlacklist);
				pstmtCheckBlacklist.setString(1, search);
				ResultSet rsCheckBlacklist = pstmtCheckBlacklist.executeQuery();
				rsCheckBlacklist.next();
				int countBlacklist = rsCheckBlacklist.getInt(1);
				if (countBlacklist > 0)
				{
					System.out.println("해당 회원은 블랙리스트에 등록되어 있어 삭제할 수 없습니다.");
					System.out.println();
				}
				else
				{
					pstmt.setString(1, search);
					int updateCount = pstmt.executeUpdate();
					System.out.println("해당 회원이 삭제 되었습니다.(" + updateCount + ")");
					System.out.println();
				}
			}
		}
		catch (Exception e)
		{
			System.out.println("해당 회원이 삭제되지 않았습니다.\n" + e.getMessage());
		}
	}
	public static void addblack(PreparedStatement pstmt, Connection con)
	{
		System.out.print("ID : ");
		String blackid = sc.nextLine();
		System.out.print("등록일 : ");
		String blackday = sc.nextLine();
		System.out.print("사유 : ");
		String blackrs = sc.nextLine();

		try
		{
			// 중복 아이디 확인
			String checkId = "SELECT COUNT(*) FROM member_book WHERE id = ?";
			PreparedStatement pstmtCheckId = con.prepareStatement(checkId);
			pstmtCheckId.setString(1, blackid);
			ResultSet rs = pstmtCheckId.executeQuery();
			rs.next();
			
			int count = rs.getInt(1);
			
			if (count > 0)
			{
				// 기등록 아이디 여부 확인
				String checkBlacklist = "SELECT COUNT(*) FROM black_book WHERE blackid = ?";
				PreparedStatement pstmtCheckBlacklist = con.prepareStatement(checkBlacklist);
				pstmtCheckBlacklist.setString(1, blackid);
				ResultSet rsCheckBlacklist = pstmtCheckBlacklist.executeQuery();
				rsCheckBlacklist.next();
				
				int countBlacklist = rsCheckBlacklist.getInt(1);
				
				if (countBlacklist == 0)
				{
					// 블랙리스트 등록
					pstmt.setString(1, blackid);
					pstmt.setString(2, blackday);
					pstmt.setString(3, blackrs);
					int updateCount = pstmt.executeUpdate();
					System.out.println("블랙리스트에 등록되었습니다. (" + updateCount + ")");
					System.out.println();
				} else
				{
				System.out.println("이미 블랙리스트에 등록된 아이디입니다.");
				System.out.println();
				}
			}
			else
			{
				System.out.println("회원정보가 존재하지 않습니다.");
				System.out.println();
			}
		} 
		catch (Exception e)
		{
			e.getMessage();
		}
	}
	public static void selblack(PreparedStatement pstmt)
	{
		System.out.print("조회할 블랙리스트 ID : ");
		String search = sc.nextLine();

		try
		{
			pstmt.setString(1, search);
			ResultSet rs = pstmt.executeQuery();
			int count = 0;
			while (rs.next())
			{
				count++;
				String blackid = rs.getString("blackid");
				String blackday = rs.getString("blackday");
				String blackrs = rs.getString("blackrs");
				System.out.println("--------------------");
				System.out.println("ID : " + blackid);
				System.out.println("등록일 : " + blackday);
				System.out.println("사유 : " + blackrs);
				System.out.println("--------------------");
			}
			if (count == 0)
				System.out.println("조회할 데이터가 없습니다.");
				System.out.println();
		} catch (Exception e)
		{
			System.out.println("조회 중 에러가 발생했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void delblack(PreparedStatement pstmt)
	{
		System.out.print("삭제할 블랙리스트 ID : ");
		String search = sc.nextLine();

		try
		{
			pstmt.setString(1, search);
			int updateCount = pstmt.executeUpdate();
			System.out.println("블랙리스트 등록이 삭제되었습니다. (" + updateCount + ")");
			System.out.println();
		} catch (Exception e)
		{
			System.out.println("블랙리스트 등록이 삭제되지 않았습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	//-------------------------도서대여-------------------------
	public static void bookRental(PreparedStatement pstmt, PreparedStatement pstmtO, Connection con) 
	{
		System.out.print("회원 ID : ");
		String id = sc.nextLine();

		try
		{	
			// 등록된 회원인지 확인
			String checkMember = "SELECT COUNT(*) FROM member_book WHERE id = ?";
			PreparedStatement pstmtCheckMember = con.prepareStatement(checkMember);
			pstmtCheckMember.setString(1, id);
			ResultSet rsCheckMember = pstmtCheckMember.executeQuery();
			rsCheckMember.next();
			int countMember = rsCheckMember.getInt(1);
			
			if (countMember == 0)
			{
				System.out.println("등록되지 않은 회원은 대여가 불가합니다.");
				System.out.println();
			} 
			else
			{
				System.out.println("로그인 되었습니다.");
				System.out.print("도서 제목 : ");
				String booktitle = sc.nextLine();
				System.out.print("도서 번호 : ");
				String bookNumber = sc.nextLine();
				System.out.print("대여일자(Ex yyyy-MM-dd) : ");
				String outday = sc.nextLine();
				
				// 회원이 미납한 도서가 있는지 확인
				pstmtO.setString(1, id);
				ResultSet rs2 = pstmtO.executeQuery();
				rs2.next();
				int count2 = rs2.getInt(1);
				if (count2 > 0)
				{
					System.out.println("회원님이 미납한 도서가 있어 추가 대여가 불가합니다.");
					System.out.println();
				} 
				else
				{
					// 블랙리스트 여부 확인
					String checkBlacklist = "SELECT COUNT(*) FROM black_book WHERE blackid = ?";
					PreparedStatement pstmtCheckBlacklist = con.prepareStatement(checkBlacklist);
					pstmtCheckBlacklist.setString(1, id);
					ResultSet rsBlacklist = pstmtCheckBlacklist.executeQuery();
					rsBlacklist.next();
					int countBlacklist = rsBlacklist.getInt(1);
					if (countBlacklist > 0)
					{
						System.out.println("해당 회원은 블랙리스트에 등록되어 대여할 수 없습니다.");
						System.out.println();
					}
					else
					{
						// 이미 대여된 도서인지 확인
						String checkRental = "SELECT COUNT(*) FROM rental_book WHERE booknumber = ?";
						PreparedStatement pstmtCheckRental = con.prepareStatement(checkRental);
						pstmtCheckRental.setString(1, bookNumber);
						ResultSet rsCheckRental = pstmtCheckRental.executeQuery();
						rsCheckRental.next();
						int countRental = rsCheckRental.getInt(1);
						if (countRental > 0)
						{
							System.out.println("이미 대여된 도서입니다.");
							System.out.println();
						}
						else
						{
							// 도서의 수량 확인
							String checkBookIn = "SELECT bookcount FROM regist_book WHERE booknumber = ?";
							PreparedStatement pstmtCheckBookIn = con.prepareStatement(checkBookIn);
							pstmtCheckBookIn.setString(1, bookNumber);
							ResultSet rsCheckBookIn = pstmtCheckBookIn.executeQuery();
							if (rsCheckBookIn.next())
							{
								int bookInCount = rsCheckBookIn.getInt(1);
								if (bookInCount > 0)
								{
									// 도서의 수량 감소
									String updateBookIn = "UPDATE regist_book SET bookcount = bookcount - 1 WHERE booknumber = ?";
									PreparedStatement pstmtU = con.prepareStatement(updateBookIn);
									pstmtU.setString(1, bookNumber);
									int updateCountU = pstmtU.executeUpdate();
									if (updateCountU > 0) 
			                        {
										SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
								        Calendar returnDate = Calendar.getInstance();
								        returnDate.setTime(dateFormat.parse(outday));
								        returnDate.add(Calendar.DAY_OF_MONTH, 7);
								        String inDay = dateFormat.format(returnDate.getTime());
								        
										pstmt.setString(1, id);
										pstmt.setString(2, booktitle);
										pstmt.setString(3, bookNumber);
										pstmt.setString(4, outday);
										pstmt.setString(5, inDay);
										int updateCount = pstmt.executeUpdate();
										System.out.println("대여 정보가 추가되었습니다. (" + updateCount + ")");
										System.out.println();
			                        }
									else
									{
										System.out.println("해당 도서의 수량이 없습니다.");
										System.out.println();
									}
								} 
								else
								{
									System.out.println("해당하는 도서 정보가 없습니다.");
									System.out.println();
								}
							}
						}
					}
				}
			}
		} 
		catch (Exception e)
		{
			System.out.println("대여 정보가 추가되지 않았습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void bookreturn(PreparedStatement pstmt, PreparedStatement pstmtU, PreparedStatement pstmtS) 
	{
		System.out.print("반납할 도서 번호 : ");
		String search = sc.nextLine();
		System.out.print("반납할 회원 ID : ");
		String search1 = sc.nextLine();
		
		try
		{
			// 대여한 도서의 수량 확인
			pstmtS.setString(1, search);
			pstmtS.setString(2, search1);
			ResultSet rs = pstmtS.executeQuery();
			rs.next();
			int currentQuantity = rs.getInt(1);
			
			// 대여 정보 삭제
			pstmt.setString(1, search);
			pstmt.setString(2, search1);
			int updateCount = pstmt.executeUpdate();
			System.out.println("도서가 반납되었습니다. (" + updateCount + ")");
			System.out.println();

			// 도서 수량 증가
			pstmtU.setInt(1, currentQuantity);
			pstmtU.setString(2, search);
			int updateCountU = pstmtU.executeUpdate();
		} catch (Exception e)
		{
			System.out.println("도서가 반납되지 않았습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void booksel(PreparedStatement pstmt) 
	{
		System.out.print("조회할 도서 번호 : ");
		String search = sc.nextLine();

		try
		{
			pstmt.setString(1, search);
			ResultSet rs = pstmt.executeQuery();
			int count = 0;
			while (rs.next())
			{
				count++;
				String id = rs.getString("id");
				String booktitle = rs.getString("booktitle");
				String bookNumber = rs.getString("bookNumber");
				String outday = rs.getString("outday");
				String inday = rs.getString("inday");
				System.out.println("회원 ID : " + id);
				System.out.println("도서 이름 : " + booktitle);
				System.out.println("도서 번호 : " + bookNumber);
				System.out.println("대여일자 : " + outday);
				System.out.println("반납일자 : " + inday);
			}
			if (count == 0)
				System.out.println("조회할 데이터가 없습니다.");
				System.out.println();
		} catch (Exception e)
		{
			System.out.println("조회 중 에러가 발생 했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	public static void bookext(PreparedStatement pstmtS, PreparedStatement pstmtU) 
	{
		System.out.print("연장할 도서 번호 : ");
		String search = sc.nextLine();
		System.out.print("회원 ID : ");
		String search1 = sc.nextLine();

		try
		{
			pstmtS.setString(1, search);
			pstmtS.setString(2, search1);
			ResultSet rs = pstmtS.executeQuery();
			if (rs.next())
			{
				String inday = rs.getString("inday");
				String format = "yyyyMMdd";
				if (inday.contains("-"))
					format = inday.length() == 8 ? "yy-MM-dd" : "yyyy-MM-dd";
				else if (inday.contains("/"))
					format = inday.length() == 8 ? "yy/MM/dd" : "yyyy/MM/dd";
				else if (inday.length() == 6)
					format = "yyMMdd";

				SimpleDateFormat sdf = new SimpleDateFormat(format);
				Calendar c = Calendar.getInstance();
				c.setTime(sdf.parse(inday));
				c.add(Calendar.DATE, 7);
				inday = sdf.format(c.getTime());

				pstmtU.setString(1, inday);
				pstmtU.setString(2, search);
				pstmtU.setString(3, search1);
				int updateCount = pstmtU.executeUpdate();
				System.out.println("도서 대여기간이 7일 연장되었습니다. (" + updateCount + ")");
				System.out.println();
			}
			else
		    {
		        System.out.println("해당 도서와 회원의 대여 기록이 없습니다.");
		        System.out.println();
		    }
		}
		catch (Exception e)
		{
			System.out.println("에러가 발생 했습니다.\n" + e.getMessage());
			System.out.println();
		}
	}
	//------------------------메인메서드------------------------
	public static void main(String[] args)
	{
		Connection con;
		PreparedStatement pstmt1;
		PreparedStatement pstmt2;
		PreparedStatement pstmt3;
		PreparedStatement pstmt4;
		PreparedStatement pstmt5;
		PreparedStatement pstmt6;
		PreparedStatement pstmt7;
		PreparedStatement pstmt8;
		PreparedStatement pstmt9;
		PreparedStatement pstmt10;
		PreparedStatement pstmt11;
		PreparedStatement pstmt12;
		PreparedStatement pstmt13;
		PreparedStatement pstmt14;
		PreparedStatement pstmt15;
		PreparedStatement pstmt16;
		PreparedStatement pstmt17;
		PreparedStatement pstmt18;
		PreparedStatement pstmt19;
		PreparedStatement pstmt20;
		PreparedStatement pstmt21;
		PreparedStatement pstmt22;
		
		try
		{
			con = DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:xe", 
					"scott", 
					"tiger");
			//-------------------------도서관리-------------------------
			String sInsert = "insert into regist_book values (?, ?, ?) ";
			pstmt1 = con.prepareStatement(sInsert);
			String sSelect = "select * from regist_book where booknumber = ? ";
			pstmt2 = con.prepareStatement(sSelect);
			String sSelectAll = "select * from regist_book";
			pstmt3 = con.prepareStatement(sSelectAll);
			String sDelete = "delete from regist_book where booknumber = ? ";
			pstmt4 = con.prepareStatement(sDelete);
			String updateBookIn = "UPDATE regist_book SET bookcount = bookcount - ? WHERE booknumber = ? AND booktitle = ?";
			pstmt22 = con.prepareStatement(updateBookIn);
			//-------------------------회원관리-------------------------
			String mInsert = "insert into member_book values (?, ?) ";
			pstmt5 = con.prepareStatement(mInsert);
			String mSelect = "select * from member_book where id = ?";
			pstmt6 = con.prepareStatement(mSelect);
			String mDelete = "delete from member_book where id = ?";
			pstmt7 = con.prepareStatement(mDelete);
			String sRentalCount = "SELECT COUNT(*) FROM rental_book WHERE id = ?";
			pstmt8 = con.prepareStatement(sRentalCount);
			String sRentalBookNumber = "SELECT booknumber FROM rental_book WHERE id = ?";
			pstmt18 = con.prepareStatement(sRentalBookNumber);
			String sBlacklistCheck = "SELECT * FROM black_book WHERE blackid = ?";
			pstmt19 = con.prepareStatement(sBlacklistCheck);
			//----------------------블랙리스트관리----------------------
			String bInsert = "insert into black_book values (?, ?, ?) ";
			pstmt9 = con.prepareStatement(bInsert);
			String bSelect = "select * from black_book where blackid = ? ";
			pstmt10 = con.prepareStatement(bSelect);
			String bDelete = "delete from black_book where blackid = ? ";
			pstmt11 = con.prepareStatement(bDelete);
			//-------------------------대출관리-------------------------
			String rInsert = "insert into rental_book values (?, ?, ?, ?, ?, 0) ";
			pstmt12 = con.prepareStatement(rInsert);
			String rSelect = "select * from rental_book where booknumber = ?";
			pstmt13 = con.prepareStatement(rSelect);
			String rDelete = "delete from rental_book where booknumber = ? and id = ?";
			pstmt14 = con.prepareStatement(rDelete);
			String rReturn = "select inday from rental_book where booknumber = ? and id = ?";
			pstmt15 = con.prepareStatement(rReturn);
			String rUpdate = "update rental_book set inday = ? where booknumber = ? and id = ?";
			pstmt16 = con.prepareStatement(rUpdate);
			String sCheck = "SELECT COUNT(*) FROM rental_book WHERE id = ?";
			pstmt17 = con.prepareStatement(sCheck);
			String sUpdateBookIn = "UPDATE regist_book SET bookcount = bookcount + ? WHERE booknumber = ?";
			pstmt20 = con.prepareStatement(sUpdateBookIn);
			String sSelectRentalQuantity = "SELECT COUNT(*) FROM rental_book WHERE booknumber = ? AND id = ?";
			pstmt21 = con.prepareStatement(sSelectRentalQuantity);
			
			int choice;
			int rchoice;
			int mchoice;
			int lchoice;
			while(true)
			{
				mainMenu();
				choice = sc.nextInt();
				sc.nextLine();
				switch (choice)
				{
				case 1:
					//도서 메뉴
					System.out.println();
					registMenu();
					rchoice = sc.nextInt();
					sc.nextLine();
						switch (rchoice)
						{
						case 1:
							addNumber(pstmt1, con);
							break;
						case 2:
							selNumber(pstmt2);
							break;
						case 3:
							selectAll(pstmt3);
							break;
						case 4:
							delNumber(pstmt4, pstmt22, con);
							break;
						case 5:
							break;
						case 6:
							System.out.println("프로그램을 종료합니다.");
							pstmt1.close();
							pstmt2.close();
							pstmt3.close();
							pstmt4.close();
							con.close();
							return;
						default:
							System.out.println("잘 못 입력하셨습니다.");
							break;
						}
						break;
						
				case 2:
					//회원 메뉴
					System.out.println();
					memberMenu();
					mchoice = sc.nextInt();
					sc.nextLine();
						switch (mchoice)
						{
						case 1:
							addMember(pstmt5, con);
							break;
						case 2:
							selMember(pstmt6, pstmt8, pstmt18, pstmt19);
							break;
						case 3:
							delMember(pstmt7, pstmt8, con);
							break;
						case 4:
							addblack(pstmt9, con);
							break;
						case 5:
							selblack(pstmt10);
							break;
						case 6:
							delblack(pstmt11);
							break;
						case 7:
							break;
						case 8:
							System.out.println("프로그램을 종료합니다.");
							pstmt5.close();
							pstmt6.close();
							pstmt7.close();
							pstmt8.close();
							pstmt9.close();
							pstmt10.close();
							pstmt11.close();
							con.close();
							return;
						default:
							System.out.println("잘 못 입력하셨습니다.");
							break;
						}
						break;
					
				case 3:
					//대출 메뉴
					System.out.println();
					rentalMenu();
					lchoice = sc.nextInt();
					sc.nextLine();
						switch (lchoice)
						{
						case 1:
							bookRental(pstmt12, pstmt17, con);
							break;
						case 2:
							bookreturn(pstmt14, pstmt20, pstmt21);
							break;
						case 3:
							booksel(pstmt13);
							break;
						case 4:
							bookext(pstmt15, pstmt16);
							break;
						case 5:
							break;
						case 6:
							System.out.println("프로그램을 종료합니다.");
							pstmt12.close();
							pstmt13.close();
							pstmt14.close();
							pstmt15.close();
							pstmt16.close();
							pstmt17.close();
							con.close();
							return;
						default:
							System.out.println("잘 못 입력하셨습니다.");
							break;
						}
						break;
						
				case 4:
					System.out.println("프로그램을 종료합니다.");
					
					con.close();
					return;
				default:
					System.out.println("잘 못 입력하셨습니다.");
					break;
				}
			}
		}
		catch (SQLException sqle)
		{
			System.out.println("Connection Error");
			sqle.printStackTrace();
		}
	}

}
