package data;

public class Data 
{
	private int dataID;
	private String dataTitle;
	private String userID;
	private String dataDate;
	private String dataContent;
	private int dataAvailable;
	private int dataCount;
	private int likeCount;
	private String filename;
	
	public int getDataID()
	{
		return dataID;
	}
	public void setDataID(int dataID)
	{
		this.dataID = dataID;
	}
	public String getDataTitle()
	{
		return dataTitle;
	}
	public void setDataTitle(String dataTitle)
	{
		this.dataTitle = dataTitle;
	}
	public String getUserID()
	{
		return userID;
	}
	public void setUserID(String userID)
	{
		this.userID = userID;
	}
	public String getDataDate()
	{
		return dataDate;
	}
	public void setDataDate(String dataDate)
	{
		this.dataDate = dataDate;
	}
	public String getDataContent()
	{
		return dataContent;
	}
	public void setDataContent(String dataContent)
	{
		this.dataContent = dataContent;
	}
	public int getDataAvailable()
	{
		return dataAvailable;
	}
	public void setDataAvailable(int dataAvailable)
	{
		this.dataAvailable = dataAvailable;
	}
	public int getDataCount()
	{
		return dataCount;
	}
	public void setDataCount(int bbsCount)
	{
		this.dataCount = bbsCount;
	}
	public int getLikeCount()
	{
		return likeCount;
	}
	public void setLikeCount(int likeCount)
	{
		this.likeCount = likeCount;
	}
	public String getFilename()
	{
		return filename;
	}
	public void setFilename(String filename)
	{
		this.filename = filename;
	}
	
}
