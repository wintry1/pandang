import 'package:memo/data/note.dart';
import 'package:sqflite/sqflite.dart';

class NoteManager {
  static const _databaseName = 'notes.db';
  static const _databaseVersion = 2;  // 데이터베이스 버전을 업데이트합니다.

  Database? _database;

  Future<void> addNote(Note note) async {
    final db = await _getDatabase();
    await db.insert(Note.tableName, note.toRow());
  }

  Future<void> deleteNote(int id) async {
    final db = await _getDatabase();
    await db.delete(
      Note.tableName,
      where: '${Note.columnId} = ?',
      whereArgs: [id],
    );
  }

  Future<Note> getNote(int id) async {
    final db = await _getDatabase();
    final rows = await db.query(
      Note.tableName,
      where: '${Note.columnId} = ?',
      whereArgs: [id],
    );
    return Note.fromRow(rows.single);  // 여기에서 글자색이 데이터베이스에서 로드됩니다.
  }
  
  Future<List<Note>> listNotes() async {
    final db = await _getDatabase();
    final rows = await db.query(Note.tableName);
    return rows.map((row) => Note.fromRow(row)).toList();
  }

  Future<void> updateNote(int id, Note note) async {
    final db = await _getDatabase();
    await db.update(
      Note.tableName,
      note.toRow(),  // 여기에서 글자색이 데이터베이스에 저장됩니다.
      where: '${Note.columnId} = ?',
      whereArgs: [id],
    );
  }

  Future<Database> _getDatabase() async {
    _database ??= await openDatabase(
      _databaseName,
      version: _databaseVersion,
      onCreate: (db, version) {
        const sql = '''
          CREATE TABLE ${Note.tableName} (
            ${Note.columnId} INTEGER PRIMARY KEY AUTOINCREMENT,
            ${Note.columnTitle} TEXT,
            ${Note.columnBody} TEXT NOT NULL,
            ${Note.columnColor} INTEGER NOT NULL,
            ${Note.columnTextColor} INTEGER NOT NULL
          )
        ''';
        return db.execute(sql);
      },
      onUpgrade: (db, oldVersion, newVersion) {  // onUpgrade 콜백을 추가하여 기존 테이블을 업데이트합니다.
        if (oldVersion < 2) {
          db.execute('ALTER TABLE ${Note.tableName} ADD COLUMN ${Note.columnTextColor} INTEGER');
        }
      },
    );
    return _database!;
  }
}