import 'package:flutter/material.dart';

class Note {
  static const colorDefault = Colors.white;
  static const textDefault = Colors.black;
  static const colorRed = Color(0xFFFFCDD2);
  static const colorOrange = Color(0xFFFFE0B2);
  static const colorYellow = Color(0xFFFFF9C4);
  static const colorLime = Color(0xFFF0F4C3);
  static const colorBlue = Color(0xFFBBDEFB);
  
  static const tableName = 'notes';
  static const columnId = 'id';
  static const columnTitle = 'title';
  static const columnBody = 'body';
  static const columnColor = 'color';
  static const columnTextColor = 'textColor';  // 글자색을 나타내는 열의 이름을 저장하는 상수를 추가합니다.

  final int? id;
  final String title;
  final String body;
  final Color color;
  final Color textColor;  // 글자색을 저장하는 속성을 추가합니다.

  Note(
    this.body, {
    this.id,
    this.title = '',
    this.color = colorDefault,
    this.textColor = textDefault,
  });
  
  Note.fromRow(Map<String, dynamic> row)
      : this(
        row[columnBody],
        id: row[columnId],
        title: row[columnTitle],
        color: Color(row[columnColor]),
        textColor: Color(row[columnTextColor]), // 데이터베이스에서 글자 색상을 로드
      );
  
  Map<String, dynamic> toRow() {
    
    return {
      columnTitle: title,
      columnBody: body,
      columnColor: color.value,
      columnTextColor: textColor.value,  // 글자색을 데이터베이스에 저장합니다.
    };
  }
}