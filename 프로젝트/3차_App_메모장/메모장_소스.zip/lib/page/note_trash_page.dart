import 'package:flutter/material.dart';
import 'package:memo/data/note.dart';
import 'package:memo/page/note_view_page.dart';
import 'package:memo/providers.dart';
import 'package:memo/page/note_list_page.dart';

GlobalKey<NavigatorState> noteListNavigatorKey = GlobalKey<NavigatorState>();

class NoteTrashPage extends StatefulWidget {
  const NoteTrashPage({Key? key}) : super(key: key);

  @override
  State<NoteTrashPage> createState() => _NoteTrashPageState();
}

var scaffoldKey = GlobalKey<ScaffoldState>();

class _NoteTrashPageState extends State<NoteTrashPage> {
  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('휴지통'),
        backgroundColor: Colors.blue,
        leading: Builder(builder: (context) =>
          IconButton(onPressed: () => Scaffold.of(context).openDrawer(), icon: const Icon(Icons.menu)
          ),
        ),
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            Container(
              height: 90,
              child: const DrawerHeader(
                decoration: BoxDecoration(
                  color: Colors.blue,
                ),
                child: Text(
                  '메뉴',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                  ),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.notes),
              title: const Text('모든 노트'),
              onTap: (() {
                noteListNavigatorKey.currentState?.pop();
                Navigator.push(context, MaterialPageRoute(builder: (context) => NoteListPage()));
                scaffoldKey.currentState!.openEndDrawer();
              }),
            ),
            ListTile(
              leading: const Icon(Icons.restore_from_trash),
              title: const Text('휴지통'),
              onTap: (() {
                Navigator.push(context, MaterialPageRoute(builder: (context) => NoteTrashPage()));
                scaffoldKey.currentState!.openEndDrawer();
              }),
            ),
          ],
        ),
      ),
      body: FutureBuilder<List<Note>>(
        future: noteManager().listNotes(),
        builder: (context, snapshot) {
          if(snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(),
            );
          }
          if(snapshot.hasError) {
            return Scaffold(
              appBar: AppBar(),
              body: const Center(
                child: Text('오류가 발생했습니다'),
              ),
            );
          }
          final notes = snapshot.requireData;
          return GridView.builder(
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: 1,
              ),
              padding: const EdgeInsets.symmetric(
                horizontal: 12,
                vertical: 16,
              ),
              itemCount: notes.length,
              itemBuilder: (BuildContext context, int index) => _buildCard(notes[index]),
          );
        }
      ),
    );
  }

  Widget _buildCard(Note note) {
    return InkWell(
      onTap: () {
        Navigator.pushNamed(
          context, 
          NoteViewPage.routeName, 
          arguments: note.id)
            .then((_) {
            setState(() {});
          });
      },
      child: Card(
        color: note.color,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text(
                note.title.isEmpty ?'(제목없음)' : note.title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(
                height: 16,
              ),
              Expanded(
                child: Text(
                  note.body,
                  overflow: TextOverflow.fade,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}