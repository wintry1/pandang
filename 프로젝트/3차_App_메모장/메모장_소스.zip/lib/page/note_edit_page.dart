import 'package:flutter/material.dart';
import 'package:memo/data/note.dart';
import 'package:memo/providers.dart';

class NoteEditPage extends StatefulWidget {
  const NoteEditPage({Key? key, this.id}) : super(key: key);

  static const routeName = '/edit';

  final int? id;

  @override
  State<NoteEditPage> createState() => _NoteEditPageState();
}

class _NoteEditPageState extends State<NoteEditPage> {
  final TextEditingController titleController = TextEditingController();
  final TextEditingController bodyController = TextEditingController();
  
  Color memoColor = Note.colorDefault;
  Color textColor = Colors.black;  // 글자색을 저장하는 변수를 추가합니다.

  late FocusNode _bodyFocusNode; // Declare a FocusNode for the second TextField

  @override
  void initState() {
    super.initState();
    final noteId = widget.id;
    _bodyFocusNode = FocusNode(); // Initialize the FocusNode
    if (noteId != null) {
      noteManager().getNote(noteId).then((note) {
        titleController.text = note.title;
        bodyController.text = note.body;
        setState(() {
          memoColor = note.color;
          textColor = note.textColor;
        });
      });
    }
  }

  @override
  void dispose() {
    // Dispose of the FocusNode when the widget is disposed to avoid memory leaks
    _bodyFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('노트 편집'),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            onPressed: _displayColorSelectionDialog,
            icon: const Icon(Icons.color_lens),
            tooltip: '배경색 선택',
          ),
          IconButton(
            onPressed: _displayTextColorSelectionDialog,  // 글자색 선택 다이얼로그를 표시하는 함수를 호출합니다.
            icon: const Icon(Icons.format_color_text),
            tooltip: '글자색 선택',
          ),
          IconButton(
            onPressed: _saveNote,
            icon: const Icon(Icons.save),
            tooltip: '저장',
          ),
        ],
      ),
      body: SizedBox.expand(
        child: GestureDetector(
          onTap: () {
            // Set focus to the second TextField when the container is tapped
            FocusScope.of(context).requestFocus(_bodyFocusNode);
          },
          child: Container(
            color: memoColor,
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                    maxLength: 10,
                    decoration: const InputDecoration(
                      border: OutlineInputBorder(),
                      label: Text('제목 입력'),
                    ),
                    maxLines: 1,
                    controller: titleController,
                  ),
                  const SizedBox(
                    height: 8,
                  ),
                  TextField(
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: '내용 입력',
                    ),
                    maxLines: null,
                    keyboardType: TextInputType.multiline,
                    controller: bodyController,
                    focusNode: _bodyFocusNode,
                    style: TextStyle(
                      fontSize: 20,
                      color: textColor,  // 글자색을 설정합니다.
                    ),
                  ),
                  ElevatedButton(
                    child: const Text('키보드 내리기',
                                      style: TextStyle(fontSize: 24,
                                                color: Colors.blue)),
                    onPressed: () => _onClick(),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _onClick() {
    FocusScope.of(context).unfocus();
  }

  void _displayColorSelectionDialog() {
    FocusManager.instance.primaryFocus!.unfocus();

    showDialog(
      context: context, 
      builder: (context) {
        return AlertDialog(
          title: Text('배경색 선택'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text('없음'),
                onTap: () => _applyColor(Note.colorDefault),
              ),
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Note.colorRed,
                ),
                title: Text('빨간색'),
                onTap: () => _applyColor(Note.colorRed),
              ),
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Note.colorLime,
                ),
                title: Text('연두색'),
                onTap: () => _applyColor(Note.colorLime),
              ),
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Note.colorBlue,
                ),
                title: Text('파란색'),
                onTap: () => _applyColor(Note.colorBlue),
              ),
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Note.colorOrange,
                ),
                title: Text('주황색'),
                onTap: () => _applyColor(Note.colorOrange),
              ),
              ListTile(
                leading: CircleAvatar(
                  backgroundColor: Note.colorYellow,
                ),
                title: Text('노란색'),
                onTap: () => _applyColor(Note.colorYellow),
              ),
            ],
          ),
        );
      },
    );
  }

  void _applyColor(Color newColor) {
    setState(() {
      Navigator.pop(context);
      memoColor = newColor;
    });
  }

  void _displayTextColorSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text('글자색 선택'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                title: Text('검정색'),
                onTap: () => _applyTextColor(Colors.black),
              ),
              ListTile(
                title: Text('빨간색'),
                onTap: () => _applyTextColor(Colors.red),
              ),
              ListTile(
                title: Text('파란색'),
                onTap: () => _applyTextColor(Colors.blue),
              ),
              // 필요한 만큼 다른 색상을 추가할 수 있습니다.
            ],
          ),
        );
      },
    );
  }

  void _applyTextColor(Color newColor) {
    setState(() {
      Navigator.pop(context);
      textColor = newColor;  // 선택한 색상을 글자색으로 설정합니다.
    });
  }

  void _saveNote() {
    if (bodyController.text.isNotEmpty) {
      final note = Note(
        bodyController.text,
        title: titleController.text,
        color: memoColor,
        textColor: textColor
      );
      final noteIndex = widget.id;
      if (noteIndex != null) {
        noteManager().updateNote(noteIndex, note);
      } else {
        noteManager().addNote(note);
      }
      Navigator.pop(context);
    } else {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('내용을 입력하세요.'),
      behavior: SnackBarBehavior.floating,
      ));
    }
  }
}